(function () {
  'use strict';

  const debounce = (fn, wait) => {
    let timeout;
    return (...args) => {
      window.clearTimeout(timeout);
      timeout = window.setTimeout(() => fn.apply(null, args), wait);
    };
  };

  const setButtonState = (button, expanded) => {
    button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    const icon = button.querySelector('i');
    if (icon) icon.className = expanded ? 'fas fa-times' : 'fas fa-bars';
  };


  // Lightweight live date/time for the header. Uses the site's WordPress timezone when available.
  document.querySelectorAll('.site-clock').forEach((siteClock) => {
    const dateEl = siteClock.querySelector('.clock-date');
    const timeEl = siteClock.querySelector('.clock-time');
    const timeZone = siteClock.getAttribute('data-timezone') || undefined;
    const updateClock = () => {
      const now = new Date();
      try {
        if (dateEl) dateEl.textContent = new Intl.DateTimeFormat(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', timeZone }).format(now);
        if (timeEl) timeEl.textContent = new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZone }).format(now);
      } catch (error) {
        if (timeEl) timeEl.textContent = now.toLocaleTimeString();
      }
    };
    updateClock();
    window.setInterval(updateClock, 1000);
  });

  // Reading progress bar.
  const progressBar = document.getElementById('reading-progress');
  const updateProgress = () => {
    if (!progressBar) return;
    const content = document.getElementById('post-content');
    if (!content) return;
    const contentTop = content.offsetTop;
    const maxScroll = Math.max(1, content.offsetHeight - window.innerHeight * 0.35);
    const scrolled = window.scrollY - contentTop;
    const progress = Math.min(100, Math.max(0, (scrolled / maxScroll) * 100));
    progressBar.style.width = `${progress}%`;
  };

  if (progressBar) {
    window.addEventListener('scroll', debounce(updateProgress, 16), { passive: true });
    window.addEventListener('resize', debounce(updateProgress, 100), { passive: true });
    updateProgress();
  }

  // Mobile navigation with ARIA and keyboard close.
  const navToggle = document.getElementById('nav-toggle');
  const primaryNav = document.getElementById('primary-nav');
  if (navToggle && primaryNav) {
    navToggle.setAttribute('aria-controls', 'primary-nav');
    setButtonState(navToggle, false);

    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('open');
      setButtonState(navToggle, isOpen);
    });

    document.addEventListener('click', (event) => {
      if (!primaryNav.contains(event.target) && !navToggle.contains(event.target)) {
        primaryNav.classList.remove('open');
        setButtonState(navToggle, false);
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        primaryNav.classList.remove('open');
        setButtonState(navToggle, false);
        navToggle.focus();
      }
    });
  }



  // Mobile search panel. It is absolute-positioned so the header height stays stable.
  const searchToggle = document.getElementById('search-toggle');
  const headerSearch = document.getElementById('header-search');
  if (searchToggle && headerSearch) {
    const setSearchState = (open) => {
      document.body.classList.toggle('search-open', open);
      if (open && primaryNav && navToggle) {
        primaryNav.classList.remove('open');
        setButtonState(navToggle, false);
      }
      searchToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      const icon = searchToggle.querySelector('i');
      if (icon) icon.className = open ? 'fas fa-times' : 'fas fa-search';
      if (open) {
        const input = headerSearch.querySelector('input[type="search"]');
        if (input) window.setTimeout(() => input.focus(), 30);
      }
    };

    searchToggle.addEventListener('click', () => {
      setSearchState(!document.body.classList.contains('search-open'));
    });

    document.addEventListener('click', (event) => {
      if (!document.body.classList.contains('search-open')) return;
      if (headerSearch.contains(event.target) || searchToggle.contains(event.target)) return;
      setSearchState(false);
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && document.body.classList.contains('search-open')) {
        setSearchState(false);
        searchToggle.focus();
      }
    });
  }

  // Pause the running ticker on hover/focus for accessibility.
  const ticker = document.querySelector('#breaking-news .ticker-track');
  if (ticker) {
    ['mouseenter', 'focusin'].forEach(evt => ticker.addEventListener(evt, () => ticker.style.animationPlayState = 'paused'));
    ['mouseleave', 'focusout'].forEach(evt => ticker.addEventListener(evt, () => ticker.style.animationPlayState = 'running'));
  }

  // Keep sticky header stable on scroll. Do not shrink or move the header.

  // Safe smooth scroll for same-page anchors.
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (event) => {
      const hash = anchor.getAttribute('href');
      if (!hash || hash === '#') return;
      const target = document.querySelector(hash);
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // Lazy reveal.
  if ('IntersectionObserver' in window) {
    document.documentElement.classList.add('has-reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -32px 0px' });

    document.querySelectorAll('.post-card, .post-list-item, .hero-small-card, .widget').forEach(el => observer.observe(el));
  }


  // Looping typewriter effect for the author bio with emoji rotation.
  document.querySelectorAll('.typewriter-text').forEach((element) => {
    let items = [];
    const jsonItems = element.getAttribute('data-type-items');
    if (jsonItems) {
      try {
        items = JSON.parse(jsonItems);
      } catch (error) {
        items = [];
      }
    }
    if (!Array.isArray(items) || !items.length) {
      const fallbackText = element.getAttribute('data-type-text') || element.textContent || '';
      items = fallbackText ? [fallbackText] : [];
    }
    if (!items.length) return;

    const widget = element.closest('.about-widget');
    const emojiEl = widget ? widget.querySelector('.author-emoji') : null;
    let emojis = [];
    if (emojiEl) {
      const emojiJson = emojiEl.getAttribute('data-emoji-items');
      if (emojiJson) {
        try {
          emojis = JSON.parse(emojiJson);
        } catch (error) {
          emojis = [];
        }
      }
    }

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      element.textContent = items.join(' · ');
      if (emojiEl && emojis.length) {
        emojiEl.textContent = emojis[0];
      }
      return;
    }

    element.classList.add('is-typing');
    let itemIndex = 0;
    let charIndex = 0;
    let deleting = false;

    const step = () => {
      const currentText = items[itemIndex] || '';
      if (emojiEl && emojis.length) {
        emojiEl.textContent = emojis[itemIndex % emojis.length];
      }

      if (!deleting) {
        charIndex += 1;
        element.textContent = currentText.slice(0, charIndex);
        if (charIndex < currentText.length) {
          const currentChar = currentText.charAt(charIndex - 1);
          const delay = currentChar === ' ' ? 46 : currentChar === '·' || currentChar === '၊' || currentChar === ',' ? 120 : 34;
          window.setTimeout(step, delay);
        } else {
          deleting = true;
          window.setTimeout(step, 1300);
        }
      } else {
        charIndex -= 1;
        element.textContent = currentText.slice(0, Math.max(charIndex, 0));
        if (charIndex > 0) {
          window.setTimeout(step, 18);
        } else {
          deleting = false;
          itemIndex = (itemIndex + 1) % items.length;
          window.setTimeout(step, 260);
        }
      }
    };

    element.textContent = '';
    window.setTimeout(step, 300);
  });

  // Copy link buttons without inline JS dependency.
  document.querySelectorAll('.share-btn.cp').forEach(button => {
    button.addEventListener('click', async () => {
      const url = button.getAttribute('data-copy-url') || window.location.href;
      try {
        await navigator.clipboard.writeText(url);
        button.innerHTML = '<i class="fas fa-check"></i> Copied!';
      } catch (error) {
        button.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Copy failed';
      }
      window.setTimeout(() => {
        button.innerHTML = '<i class="fas fa-link"></i> Copy Link';
      }, 2500);
    });
  });
})();

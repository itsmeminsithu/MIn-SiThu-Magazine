---
name: Bug report
about: Report a theme bug
title: "[Bug] "
labels: bug
assignees: ''
---

## Problem

## Steps to reproduce

## Expected result

## Screenshot

## WordPress/PHP version
